<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\DebugInterface;

/**
 * @see DebugInterface
 */
interface Debug extends DebugInterface
{
}
