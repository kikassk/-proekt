<?php

namespace Hleb;

use Hleb\Constructor\Attributes\NotFinal;

#[NotFinal]
class InvalidLogLevelException extends CoreProcessException
{
}
