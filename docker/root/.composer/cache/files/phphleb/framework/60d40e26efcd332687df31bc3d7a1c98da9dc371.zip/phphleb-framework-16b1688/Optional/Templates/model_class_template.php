<?php

namespace model_namespace_template;

use Hleb\Base\Model;

class model_class_template extends Model
{
    /**
     * model_description_template
     */
    public static function get()
    {
        // Your code here.
    }
}
