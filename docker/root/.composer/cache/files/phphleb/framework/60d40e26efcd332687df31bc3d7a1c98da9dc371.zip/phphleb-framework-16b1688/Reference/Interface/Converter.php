<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\ConverterInterface;

/**
 * @see ConverterInterface
 */
interface Converter extends ConverterInterface
{

}
