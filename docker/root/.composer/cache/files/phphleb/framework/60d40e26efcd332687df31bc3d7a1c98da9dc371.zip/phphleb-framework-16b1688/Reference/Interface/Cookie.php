<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\CookieInterface;

/**
 * @see CookieInterface
 */
interface Cookie extends CookieInterface
{
}
