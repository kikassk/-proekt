<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\SessionInterface;

/**
 * @see SessionInterface
 */
interface Session extends SessionInterface
{
}
