# Security Policy

-----
Please contact the author to let us know about any security issue you find in the [phphleb](https://github.com/phphleb) repository.
DO NOT use the issue tracker or discuss it in the public forum as it will cause more damage than help.

Please note that as a non-commercial OpenSource project we are not able to pay bounties at the moment.