<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\SettingInterface;

/**
 * @see SettingInterface
 */
interface Setting extends SettingInterface
{
}
