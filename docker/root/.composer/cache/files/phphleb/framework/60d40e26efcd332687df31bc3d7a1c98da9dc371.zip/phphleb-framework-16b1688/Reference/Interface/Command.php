<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\CommandInterface;

/**
 * @see CacheInterface
 */
interface Command extends CommandInterface
{
}
