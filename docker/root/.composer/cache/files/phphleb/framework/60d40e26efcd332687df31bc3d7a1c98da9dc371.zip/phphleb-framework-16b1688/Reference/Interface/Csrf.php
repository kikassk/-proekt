<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\CsrfInterface;

/**
 * @see CsrfInterface
 */
interface Csrf extends CsrfInterface
{
}
