<?php

namespace controller_namespace_template;

use Hleb\Base\Controller;

class controller_class_template extends Controller
{
    /**
     * controller_description_template
     */
    public function index()
    {
        // Your code here.
    }
}
