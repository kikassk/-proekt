<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\LogInterface;

/**
 * @see LogInterface
 */
interface Log extends LogInterface
{
}
