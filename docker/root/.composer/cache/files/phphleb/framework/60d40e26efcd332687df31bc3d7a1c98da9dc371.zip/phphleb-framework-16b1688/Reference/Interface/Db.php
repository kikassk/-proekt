<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\DbInterface;

/**
 * @see DbInterface
 */
interface Db extends DbInterface
{
}
