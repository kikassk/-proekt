| Q            | A                                                         |
|--------------|-----------------------------------------------------------|
| Is bugfix?   | **Yes / No**                                              |
| New feature? | **Yes / No**                                              |
| Breaks BC?   | **Yes / No**                                              |
| Fixed issues | comma-separated list of tickets # fixed by the PR, if any |

------
_Description of the changes being made._
