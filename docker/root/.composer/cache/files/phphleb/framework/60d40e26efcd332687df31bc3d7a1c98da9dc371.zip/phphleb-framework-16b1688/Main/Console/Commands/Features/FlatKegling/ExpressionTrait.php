<?php

namespace Hleb\Main\Console\Commands\Features\FlatKegling;

/**
 * @internal
 */
trait ExpressionTrait
{
    protected const LOGO = "
    █▀▀ █── █▀▀█ ▀▀█▀▀ 　 █─▄▀ █▀▀ █▀▀▀ █── ─▀─ █▀▀▄ █▀▀▀ 
    █▀▀ █── █▄▄█ ──█── 　 █▀▄ ─█▀▀ █─▀█ █── ▀█▀ █──█ █─▀█ 
    ▀── ▀▀▀ ▀──▀ ──▀── 　 ▀──▀ ▀▀▀ ▀▀▀▀ ▀▀▀ ▀▀▀ ▀──▀ ▀▀▀▀";
}
