<?php
/** @var App\Bootstrap\ContainerInterface $container */

echo "Module <b>`{$container->settings()->getModuleName()}`</b> template.";
