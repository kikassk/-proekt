<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\RouterInterface;

/**
 * @see RouterInterface
 */
interface Router extends RouterInterface
{
}
