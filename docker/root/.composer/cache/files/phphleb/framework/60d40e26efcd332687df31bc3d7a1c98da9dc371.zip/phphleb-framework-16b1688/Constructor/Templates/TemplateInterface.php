<?php

namespace Hleb\Constructor\Templates;

interface TemplateInterface
{
   public function view(): void;
}
