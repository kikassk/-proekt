<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\SystemInterface;

/**
 * @see SystemInterface
 */
interface System extends SystemInterface
{
}
