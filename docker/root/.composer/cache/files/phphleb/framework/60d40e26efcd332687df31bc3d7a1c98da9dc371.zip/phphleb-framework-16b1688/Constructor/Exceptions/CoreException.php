<?php

namespace Hleb;

/**
 * An exception was thrown in the core of the framework.
 *
 * Исключение возникло в ядре фреймворка.
 */
interface CoreException extends FrameworkException
{
}
