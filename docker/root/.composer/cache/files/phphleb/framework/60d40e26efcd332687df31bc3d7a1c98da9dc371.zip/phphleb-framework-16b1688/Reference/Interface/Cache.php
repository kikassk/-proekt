<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\CacheInterface;

/**
 * @see CacheInterface
 */
interface Cache extends CacheInterface
{
}
