<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\ArrInterface;

/**
 * @see ArrInterface
 */
interface Arr extends ArrInterface
{
}
