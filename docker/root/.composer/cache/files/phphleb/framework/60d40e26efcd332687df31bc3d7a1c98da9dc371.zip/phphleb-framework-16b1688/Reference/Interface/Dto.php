<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\DtoInterface;

/**
 * @see DtoInterface
 */
interface Dto extends DtoInterface
{
}
