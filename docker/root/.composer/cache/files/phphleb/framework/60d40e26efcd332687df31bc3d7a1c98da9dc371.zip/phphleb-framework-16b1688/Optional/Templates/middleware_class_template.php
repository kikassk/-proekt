<?php

namespace middleware_namespace_template;

use Hleb\Base\Middleware;

class middleware_class_template extends Middleware
{
    /**
     * middleware_description_template
     */
    public function index()
    {
        // Your code here.
    }
}
