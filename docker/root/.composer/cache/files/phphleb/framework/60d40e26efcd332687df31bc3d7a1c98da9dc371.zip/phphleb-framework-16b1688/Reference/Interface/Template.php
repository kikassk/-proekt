<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\TemplateInterface;

/**
 * @see TemplateInterface
 */
interface Template extends TemplateInterface
{
}
