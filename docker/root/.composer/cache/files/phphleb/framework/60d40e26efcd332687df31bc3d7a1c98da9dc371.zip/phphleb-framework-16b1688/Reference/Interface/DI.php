<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\DiInterface;

/**
 * @see DiInterface
 */
interface DI extends DiInterface
{
}
