<?php

namespace Hleb\Constructor\Actions;

interface ActionInterface
{
    public function run(): void;
}
