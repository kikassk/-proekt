<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\RequestInterface;

/**
 * @see RequestInterface
 */
interface Request extends RequestInterface
{
}
