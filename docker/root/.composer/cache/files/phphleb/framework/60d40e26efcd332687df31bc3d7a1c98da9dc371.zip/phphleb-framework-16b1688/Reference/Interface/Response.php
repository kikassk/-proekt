<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\ResponseInterface;

/**
 * @see ResponseInterface
 */
interface Response extends ResponseInterface
{
}
