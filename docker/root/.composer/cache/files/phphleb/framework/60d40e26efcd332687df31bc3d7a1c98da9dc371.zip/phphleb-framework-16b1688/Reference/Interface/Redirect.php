<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\RedirectInterface;

/**
 * @see RedirectInterface
 */
interface Redirect extends RedirectInterface
{
}
