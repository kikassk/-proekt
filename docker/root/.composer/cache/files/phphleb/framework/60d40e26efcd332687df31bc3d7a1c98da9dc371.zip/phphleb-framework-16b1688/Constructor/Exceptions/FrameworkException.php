<?php

namespace Hleb;

/**
 * The exception was generated with the participation of the framework.
 *
 * Исключение сформировано при участии фреймворка.
 */
interface FrameworkException extends \Throwable
{
}
