<?php

namespace Hleb\Reference\Interface;

use Hleb\Reference\PathInterface;

/**
 * @see PathInterface
 */
interface Path extends PathInterface
{
}
