 ## SALT

[![HLEB2](https://img.shields.io/badge/HLEB-2-darkcyan)](https://github.com/phphleb/hleb) ![PHP](https://img.shields.io/badge/PHP-^8.2-blue) [![License: MIT](https://img.shields.io/badge/License-MIT%20(Free)-brightgreen.svg)](https://github.com/phphleb/hleb/blob/master/LICENSE)

Extends IDE support for the **HLEB2** [framework](https://github.com/phphleb/hleb/).

Install using Composer:
 ```bash
composer require phphleb/salt
 ```
--------------------------

