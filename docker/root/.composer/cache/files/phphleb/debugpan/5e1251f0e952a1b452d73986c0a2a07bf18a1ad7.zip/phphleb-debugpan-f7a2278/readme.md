Debug panel for PHP Framework HLEB2
=====================


[![HLEB2](https://img.shields.io/badge/HLEB-2-darkcyan)](https://github.com/phphleb/hleb) ![PHP](https://img.shields.io/badge/PHP-^8.2-blue) [![License: MIT](https://img.shields.io/badge/License-MIT%20(Free)-brightgreen.svg)](https://github.com/phphleb/hleb/blob/master/LICENSE)


If you need to install the framework, use the link: [github.com/phphleb/hleb](https://github.com/phphleb/hleb) 